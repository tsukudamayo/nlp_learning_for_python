if __name__ == '__main__':
    print('Hello World, 自然言語処理')
